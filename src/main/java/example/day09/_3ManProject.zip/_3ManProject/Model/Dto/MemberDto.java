package example.day09._3ManProject.Model.Dto;

import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class MemberDto {

    int mno;
    String mname;
    String mphone;
}
